<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 12</title>
</head>
<body>
    
    <?php
    
    $minombre = $_GET["nombre"];
    $servidor = "localhost";
    $usuario = "root"
    $pass= "";
    $conexion = mysqli_connect($servidor,$usuario,$pass) or die("Error de conexión");
    mysqi_select_db($conexion, "alumnos");
    
    $insertar = "INSERT clientes (nombre) VALUES ('$minombre')";

    ?>


    ?>


