<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>
<body>
    
    <?php

    $num1=1
    while($num1 <= 50){
        $cuadrado=$num1*$cuadrado;
        echo $cuadrado;
        echo "<br>"
        $num1=$num1+1
    }

    ?>

